<html>
<head>
<title>Implementazione del gioco del Bantumi</title>
<meta name="author" content="Nicola Febbrari">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
<meta http-equiv="content-style-type" content="text/css">
</head>
<body>
<h2>Presentazione</h2>
<h2>Il problema</h2>
<h2>Il programma</h2>
Il programma � stato sviluppato in 2 fasi:
1) Realizzazione della struttura del gioco con TDD per implementare le regole
2) Implementazione di alcuni algoritmi di IA 
<h2>Relazione</h2>
Nella relazione ho riassunte le regole del gioco, una breve descrizione delle tecniche utilizzate per realizzare gli algoritmi di IA e alcune simulazioni di partite fra il mio programma e alcuni Bot che si trovano in commercio. 
<h4>Download</h4>
<a href="bantumi.zip">Sorgenti ZIP</a><br>
<a href="https://github.com/nickxbs/IA">Sorgenti GitHub</a><br>
<a href="bantumi.pdf">Relazione</a>
</body>
</html>