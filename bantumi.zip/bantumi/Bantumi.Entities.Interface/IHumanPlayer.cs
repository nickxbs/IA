namespace Bantumi.Entities.Interface
{
    public interface IHumanPlayer : IPlayer
    {
       
    }
}