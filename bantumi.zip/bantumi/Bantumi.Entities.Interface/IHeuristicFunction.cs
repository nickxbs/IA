﻿namespace Bantumi.Entities.Interface
{
    public interface IHeuristicFunction
    {
        int[] HeuristicFunction(IGioco gioco);
    }
}
