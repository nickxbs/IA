namespace Bantumi.Entities.Interface
{
    public interface IBuca
    {
        int Indice { get; set; }
        int Semi { get; set; }
        Lato Lato { get; set; }
    }
}