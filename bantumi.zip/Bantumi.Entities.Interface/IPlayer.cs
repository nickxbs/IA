namespace Bantumi.Entities.Interface
{
    public interface IPlayer
    {
        Lato LatoPlayer { get; set; }
    }
    public enum Lato
    {
        A,
        B
    }
}